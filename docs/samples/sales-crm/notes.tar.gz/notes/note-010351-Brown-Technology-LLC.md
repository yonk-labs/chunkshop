# Sales call note — Brown Technology LLC / Synapse AIOps / 2026-01-23

**Customer:** Brown Technology LLC (Technology · ?, ?, USA)
**Deal:** Order #257 (won, $52948.42, closed 2026-02-21)
**Product:** Synapse AIOps (Automation)
**Salesperson:** Ava Chen
**Note type:** call
**Sentiment:** unspecified

## Notes

Customer expressed interest in Synapse AIOps for their data infrastructure needs.

## Win reason

The legal team built an agent to analyze their contract database, which was previously just a "digital filing cabinet." Now they can ask, "Show me all contracts with non-standard liability clauses."
