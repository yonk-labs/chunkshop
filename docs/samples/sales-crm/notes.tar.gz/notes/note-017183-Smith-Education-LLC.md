# Sales call note — Smith Education LLC / Prometheus AI Factory / 2026-01-21

**Customer:** Smith Education LLC (Healthcare · ?, ?, USA)
**Deal:** Order #4750 (won, $22541.42, closed 2026-04-10)
**Product:** Prometheus AI Factory (uncategorized)
**Salesperson:** Liam Park
**Note type:** unspecified
**Sentiment:** unspecified

## Notes

Sent follow-up email - no response yet.

## Win reason

Their BI dashboards (Tableau) were "too static." This tool allowed them to "interactively drill down" by asking follow-up questions to the data, which was a "wow" moment for the exec team.
